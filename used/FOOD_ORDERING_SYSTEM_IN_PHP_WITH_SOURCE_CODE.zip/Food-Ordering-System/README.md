# Food-Ordering-System
Food Ordering System is a web application that manages the restaurant menu order between waiter and chef.

## Login Details
For admin:
"admin"
"password"

For staff:
check database




### Notes
1. This is not ready for production.
2. All staff created have same default password : abc123